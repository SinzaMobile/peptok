# PAMHA Developer Platform

Phase 1 of 6: scaffold, design tokens, home page shell, CI.

```bash
corepack enable && pnpm install
pnpm dev            # http://localhost:3000
pnpm test           # Vitest
pnpm test:e2e       # Playwright (builds first)
```

All routes other than `/` are placeholders marked "Coming soon". Run `pnpm install` once and commit the generated `pnpm-lock.yaml` (CI uses `--frozen-lockfile`).

Planned phases: 1 scaffold, 2 marketing, 3 OpenAPI docs, 4 control plane + console, 5 data-plane sandbox + playground, 6 demo.
