"use client";
import { useState } from "react";

const SAMPLES = {
  cURL: `curl https://sandbox.api.pamha.example/v1/events \\
  -H "Authorization: Bearer $PAMHA_SANDBOX_KEY" \\
  -H "Content-Type: application/json" \\
  -d '{
    "subject_id": "sub_7f3a9c21b8",
    "type": "checkin.completed",
    "occurred_at": "2026-10-28T08:30:00Z"
  }'`,
  TypeScript: `const res = await fetch("https://sandbox.api.pamha.example/v1/events", {
  method: "POST",
  headers: {
    Authorization: \`Bearer \${process.env.PAMHA_SANDBOX_KEY}\`,
    "Content-Type": "application/json",
  },
  body: JSON.stringify({
    subject_id: "sub_7f3a9c21b8",
    type: "checkin.completed",
    occurred_at: new Date().toISOString(),
  }),
});`,
} as const;

const RESPONSE = `{
  "wellbeing_score": 0.62,
  "confidence": 0.81,
  "reasons": ["sleep_regularity_improved"],
  "recommendation_ids": ["rec_breathing_01"],
  "safety_flags": []
}`;

export function CodePanel() {
  const [tab, setTab] = useState<keyof typeof SAMPLES>("cURL");
  return (
    <section aria-label="Example request and response" className="overflow-hidden rounded-3xl bg-panel text-panel-ink">
      <div role="tablist" className="flex gap-1 border-b border-white/10 px-4 pt-3">
        {(Object.keys(SAMPLES) as (keyof typeof SAMPLES)[]).map((k) => (
          <button key={k} role="tab" aria-selected={tab === k} onClick={() => setTab(k)}
            className={`rounded-t-lg px-3 py-2 text-sm ${tab === k ? "bg-white/10" : "text-panel-ink/60 hover:text-panel-ink"}`}>{k}</button>
        ))}
      </div>
      <pre className="overflow-x-auto p-6 font-mono text-[13px] leading-6"><code>{SAMPLES[tab]}</code></pre>
      <div className="border-t border-white/10 p-6">
        <p className="mb-3 text-xs text-panel-ink/60">Sample response. Synthetic data, structured output only. Coming soon.</p>
        <pre className="overflow-x-auto font-mono text-[13px] leading-6"><code>{RESPONSE}</code></pre>
      </div>
    </section>
  );
}
