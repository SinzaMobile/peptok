import Link from "next/link";

export function ComingSoon({ title, note }: { title: string; note?: string }) {
  return (
    <div className="mx-auto max-w-page px-6 py-24">
      <h1 className="text-3xl font-semibold tracking-tight">{title}</h1>
      <p className="mt-4 max-w-prose text-muted">Coming soon. {note ?? "This section is planned and not yet available."}</p>
      <Link href="/" className="mt-8 inline-block rounded-full border border-line px-5 py-2.5 text-sm hover:bg-line/60">Back to home</Link>
    </div>
  );
}
