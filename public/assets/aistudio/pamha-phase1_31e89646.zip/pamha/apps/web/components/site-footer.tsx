import Link from "next/link";
import { NAV } from "@/lib/nav";

export function SiteFooter() {
  return (
    <footer className="mx-auto mt-24 max-w-page px-6 pb-12">
      <div className="grid gap-8 border-t border-line pt-10 sm:grid-cols-3">
        {NAV.map((g) => (
          <div key={g.label}>
            <p className="mb-3 text-sm text-muted">{g.label}</p>
            <ul className="space-y-2 text-sm">{g.items.map((i) => <li key={i.href}><Link href={i.href} className="hover:underline">{i.label}</Link></li>)}</ul>
          </div>
        ))}
      </div>
      <p className="mt-10 max-w-prose text-sm text-muted">
        PAMHA is software infrastructure for platforms. It is not a clinical service, does not provide medical advice,
        and is not an emergency service. If someone is in immediate danger, contact local emergency services.
      </p>
    </footer>
  );
}
