"use client";
import Link from "next/link";
import { useState } from "react";
import { NAV, SIGN_IN } from "@/lib/nav";
import { Logo } from "./logo";
import { ThemeToggle } from "./theme-toggle";

export function SiteHeader() {
  const [open, setOpen] = useState(false);
  return (
    <header className="mx-auto max-w-page px-6">
      <div className="flex items-center justify-between border-b border-line py-5">
        <Link href="/" aria-label="PAMHA home"><Logo /></Link>

        <nav aria-label="Primary" className="hidden items-center gap-1 md:flex">
          {NAV.map((g) => (
            <div key={g.label} className="group relative">
              <button type="button" className="rounded-full px-3 py-2 text-muted hover:text-ink group-focus-within:text-ink">{g.label}</button>
              <ul className="invisible absolute left-0 top-full z-20 min-w-52 rounded-xl border border-line bg-bg p-2 opacity-0 shadow-sm transition-opacity group-focus-within:visible group-focus-within:opacity-100 group-hover:visible group-hover:opacity-100">
                {g.items.map((i) => (
                  <li key={i.href}>
                    <Link href={i.href} className="flex items-center justify-between gap-4 rounded-lg px-3 py-2 text-sm hover:bg-line/60">
                      {i.label}{i.status === "soon" && <span className="text-xs text-muted">Coming soon</span>}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
          <Link href={SIGN_IN.href} className="ml-2 rounded-full px-3 py-2 text-muted hover:text-ink">{SIGN_IN.label}</Link>
          <ThemeToggle />
        </nav>

        <div className="flex items-center gap-2 md:hidden">
          <ThemeToggle />
          <button type="button" aria-expanded={open} aria-controls="mobile-nav" onClick={() => setOpen(!open)}
            className="h-9 rounded-full border border-line px-4 text-sm">{open ? "Close" : "Menu"}</button>
        </div>
      </div>

      {open && (
        <nav id="mobile-nav" aria-label="Mobile" className="space-y-5 border-b border-line py-5 md:hidden">
          {NAV.map((g) => (
            <div key={g.label}>
              <p className="mb-2 text-sm text-muted">{g.label}</p>
              <ul className="space-y-1">
                {g.items.map((i) => (
                  <li key={i.href}><Link href={i.href} onClick={() => setOpen(false)} className="block py-1.5">
                    {i.label}{i.status === "soon" && <span className="ml-2 text-xs text-muted">Coming soon</span>}
                  </Link></li>
                ))}
              </ul>
            </div>
          ))}
          <Link href={SIGN_IN.href} className="block py-1.5">{SIGN_IN.label}</Link>
        </nav>
      )}
    </header>
  );
}
