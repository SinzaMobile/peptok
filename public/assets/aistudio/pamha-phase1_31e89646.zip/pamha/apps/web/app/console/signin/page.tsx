import { ComingSoon } from "@/components/coming-soon";
export const metadata = { title: "Sign in | PAMHA" };
export default function Page() {
  return <ComingSoon title="Sign in" />;
}
