import { ComingSoon } from "@/components/coming-soon";
export const metadata = { title: "Pricing | PAMHA" };
export default function Page() {
  return <ComingSoon title="Pricing" />;
}
