import { ComingSoon } from "@/components/coming-soon";
export const metadata = { title: "Try Peptok AI | PAMHA" };
export default function Page() {
  return <ComingSoon title="Try Peptok AI" />;
}
