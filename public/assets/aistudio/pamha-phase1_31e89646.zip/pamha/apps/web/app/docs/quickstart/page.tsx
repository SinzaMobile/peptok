import { ComingSoon } from "@/components/coming-soon";
export const metadata = { title: "Quickstart | PAMHA" };
export default function Page() {
  return <ComingSoon title="Quickstart" />;
}
