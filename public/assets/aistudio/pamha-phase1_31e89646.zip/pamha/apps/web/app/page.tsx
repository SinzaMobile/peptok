import Link from "next/link";
import { CodePanel } from "@/components/code-panel";

export default function Home() {
  return (
    <div className="mx-auto max-w-page px-6">
      <section className="pb-12 pt-14 sm:pt-20">
        <p className="text-sm text-muted">Adaptive mental health intelligence</p>
        <h1 className="mt-5 max-w-3xl text-4xl font-semibold tracking-tight sm:text-5xl">The intelligence layer for mental health.</h1>
        <p className="mt-5 max-w-prose text-lg leading-8 text-muted">
          Powering a new generation of digital wellbeing platforms with adaptive intelligence, personalized recommendations and meaningful insights.
        </p>
        <div className="mt-8 flex flex-wrap gap-3">
          <Link href="/platform" className="rounded-full bg-ink px-6 py-3 font-medium text-bg">Explore the platform →</Link>
          <Link href="/docs/quickstart" className="rounded-full border border-line px-6 py-3 font-medium hover:bg-line/60">Read documentation</Link>
        </div>
      </section>

      <CodePanel />

      <section className="mt-20 max-w-prose">
        <p className="text-lg leading-8">
          PAMHA is the adaptive AI infrastructure powering the next generation of digital mental health platforms. It delivers personalized
          recommendations, wellbeing tracking, analytics and context-aware intelligence through APIs that integrate into existing applications.
          Platforms deliver the experience under their own brand.
        </p>
      </section>
    </div>
  );
}
