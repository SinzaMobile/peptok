import { ComingSoon } from "@/components/coming-soon";
export const metadata = { title: "Platform | PAMHA" };
export default function Page() {
  return <ComingSoon title="Platform" />;
}
