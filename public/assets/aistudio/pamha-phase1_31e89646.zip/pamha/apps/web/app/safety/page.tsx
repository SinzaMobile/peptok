import { ComingSoon } from "@/components/coming-soon";
export const metadata = { title: "Safety and privacy | PAMHA" };
export default function Page() {
  return <ComingSoon title="Safety and privacy" />;
}
