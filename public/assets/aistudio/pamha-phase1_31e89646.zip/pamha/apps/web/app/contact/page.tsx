import { ComingSoon } from "@/components/coming-soon";
export const metadata = { title: "Contact | PAMHA" };
export default function Page() {
  return <ComingSoon title="Contact" />;
}
