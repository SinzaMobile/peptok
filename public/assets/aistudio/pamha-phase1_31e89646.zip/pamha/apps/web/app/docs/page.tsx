import { ComingSoon } from "@/components/coming-soon";
export const metadata = { title: "Documentation | PAMHA" };
export default function Page() {
  return <ComingSoon title="Documentation" />;
}
