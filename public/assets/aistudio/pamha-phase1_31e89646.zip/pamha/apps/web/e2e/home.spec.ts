import { expect, test } from "@playwright/test";

test("home renders hero, CTAs and sample request", async ({ page }) => {
  await page.goto("/");
  await expect(page.getByRole("heading", { level: 1 })).toHaveText("The intelligence layer for mental health.");
  await expect(page.getByRole("link", { name: /Explore the platform/ })).toHaveAttribute("href", "/platform");
  await expect(page.getByRole("link", { name: "Read documentation" })).toHaveAttribute("href", "/docs/quickstart");
  await page.getByRole("tab", { name: "TypeScript" }).click();
  await expect(page.locator("code").first()).toContainText("fetch(");
});

test("theme toggle switches to dark and persists", async ({ page }) => {
  await page.goto("/");
  await page.getByRole("button", { name: "Switch to dark mode" }).click();
  await expect(page.locator("html")).toHaveClass(/dark/);
  await page.reload();
  await expect(page.locator("html")).toHaveClass(/dark/);
});

test("unbuilt routes are labelled Coming soon", async ({ page }) => {
  await page.goto("/docs");
  await expect(page.getByText("Coming soon.")).toBeVisible();
});

test("mobile menu opens", async ({ page }) => {
  await page.setViewportSize({ width: 390, height: 800 });
  await page.goto("/");
  await page.getByRole("button", { name: "Menu" }).click();
  await expect(page.getByRole("navigation", { name: "Mobile" })).toBeVisible();
});
