export type NavStatus = "live" | "soon";
export type NavLink = { label: string; href: string; status: NavStatus };
export type NavGroup = { label: string; items: NavLink[] };

/** Single source of truth for header, footer and tests. "soon" items are labelled in the UI. */
export const NAV: NavGroup[] = [
  { label: "Platform", items: [
    { label: "Capabilities", href: "/platform", status: "soon" },
    { label: "Safety", href: "/safety", status: "soon" },
    { label: "Pricing", href: "/pricing", status: "soon" },
  ]},
  { label: "Developers", items: [
    { label: "Documentation", href: "/docs", status: "soon" },
    { label: "Quickstart", href: "/docs/quickstart", status: "soon" },
    { label: "Try the demo", href: "/demo", status: "soon" },
  ]},
  { label: "Company", items: [
    { label: "About", href: "/about", status: "soon" },
    { label: "Contact", href: "/contact", status: "soon" },
  ]},
];

export const SIGN_IN: NavLink = { label: "Sign in", href: "/console/signin", status: "soon" };

export const allLinks = (): NavLink[] => [...NAV.flatMap((g) => g.items), SIGN_IN];
