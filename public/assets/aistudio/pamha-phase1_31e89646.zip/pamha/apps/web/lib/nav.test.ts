import { describe, expect, it } from "vitest";
import { allLinks, NAV } from "./nav";

describe("nav config", () => {
  it("uses unique, absolute hrefs", () => {
    const hrefs = allLinks().map((l) => l.href);
    expect(new Set(hrefs).size).toBe(hrefs.length);
    hrefs.forEach((h) => expect(h.startsWith("/")).toBe(true));
  });
  it("covers every route in the approved route map", () => {
    const hrefs = allLinks().map((l) => l.href);
    for (const r of ["/platform", "/safety", "/pricing", "/docs", "/demo", "/about", "/contact", "/console/signin"])
      expect(hrefs).toContain(r);
  });
  it("has no consumer-product routes", () => {
    allLinks().forEach((l) => expect(l.href).not.toMatch(/mood|journal|booking|community/));
  });
  it("has the three top-level groups", () => {
    expect(NAV.map((g) => g.label)).toEqual(["Platform", "Developers", "Company"]);
  });
});
