import type { Config } from "tailwindcss";
const v = (n: string) => `rgb(var(--${n}) / <alpha-value>)`;
export default {
  darkMode: ["class"],
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: { bg: v("bg"), ink: v("ink"), muted: v("muted"), line: v("line"), panel: v("panel"), "panel-ink": v("panel-ink") },
      fontFamily: { sans: ["var(--font-sans)", "system-ui", "sans-serif"], mono: ["ui-monospace", "SFMono-Regular", "Menlo", "monospace"] },
      maxWidth: { page: "72rem", prose: "40rem" },
    },
  },
} satisfies Config;
